# Used to drop tables...duh
# --------------------------------------------------------

DROP TABLE IF EXISTS logs 
DROP TABLE IF EXISTS users 
DROP TABLE IF EXISTS search_cache 
DROP TABLE IF EXISTS user_access 
DROP TABLE IF EXISTS actions 
DROP TABLE IF EXISTS cemdb 
